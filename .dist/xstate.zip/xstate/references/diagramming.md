# Render XState with Mermaid

## Render from the final machine

For a visualisation-only request, preserve the implementation unless the user also asks for a design or code change.

Trace each `createMachine` definition. Include initial, final, compound, and parallel states; targeted `on`, `always`, `after`, and completion transitions; guards; invokes; and intentionally global root transitions. Mark proposed machines as proposed; cite the source for existing machines.

Show state-changing transitions; omit targetless actions and context-only events. Show a self-transition only when re-entry matters. State material omissions below the diagram.

## Keep machine boundaries visible

Render one diagram per independent `createMachine`, and an invoked state machine separately when its lifecycle matters. Describe callback, promise, observable, transition, and other non-statechart actors as resources or attempts, without inventing internal states for them.

Use a flowchart only when the user also asks for actor-system composition.

## Map XState semantics

| XState                        | Mermaid                                                   |
| ----------------------------- | --------------------------------------------------------- |
| Machine or compound `initial` | `[*] --> stateId` in that scope                           |
| `type: "final"`               | `finalId --> [*]` in the owning scope                     |
| Targeted `on`                 | `source --> target: EVENT`                                |
| Guard                         | Add its short meaning after the event                     |
| `always`                      | Label `always - condition`                                |
| `after`                       | Label the delay meaning                                   |
| `onDone`                      | Label `complete` or `all regions complete`                |
| Parallel state                | Composite regions separated by `--`                       |
| Guarded destinations          | `state choiceId <<choice>>`                               |
| State invoke                  | State description such as `Active - invokes liveResource` |

Use public event names when readable. Describe guard meaning in plain language, not copied code.

## Keep composite transitions legal

Mermaid does not support a transition between internal states of two different composites, yet its parser accepts such a line, so parsing alone will not catch the mistake. Keep both endpoints in one lexical composite. For an exit from a nested state, draw the transition from the nearest owning composite and explain the internal source when it matters. Draw only transitions the machine can take; do not invent a child-to-root shortcut in place of the legal parent transition.

```mermaid
stateDiagram-v2
    [*] --> journey
    state journey {
        [*] --> active
        active --> retrying: FAILED
        retrying --> active: RETRY
    }
    journey --> unavailable: ACCESS_REVOKED
```

The root arrow leaves `journey`; it does not connect an internal state directly to `unavailable`.

Describe a multi-target transition across parallel regions in prose. Cross-region arrows are illegal and can imply false ordering.

## Render parallel states and choices

Represent a parallel state as one composite with `--` between regions. Give each region an initial state. When the parent waits for every region, end each region at `[*]` and label the parent transition `all regions complete`.

```mermaid
stateDiagram-v2
    [*] --> preparing
    state preparing {
        state channel {
            [*] --> pendingChannel
            pendingChannel --> readyChannel: CHANNEL_READY
            readyChannel --> [*]
        }
        --
        state data {
            [*] --> pendingData
            pendingData --> readyData: DATA_READY
            readyData --> [*]
        }
    }
    preparing --> active: all regions complete
```

Wrap a root parallel machine in a named outer composite and connect `[*]` to it. Use Mermaid concurrency for persistent parallel regions. Reserve `<<fork>>` and `<<join>>` for actual fork or join semantics.

Use `<<choice>>` when guards route one event to several states. Keep the choice and its destinations in one composite scope.

```mermaid
stateDiagram-v2
    state statusChanged <<choice>>
    active --> statusChanged: STATUS_CHANGED
    statusChanged --> active: usable
    statusChanged --> degraded: degraded
```

## Use safe syntax

Start with exactly `stateDiagram-v2`. Use `direction TB` for hierarchy or concurrency and `direction LR` for a small flat lifecycle.

Use stable identifiers without spaces or punctuation, with readable labels added separately as `stateId: Readable label`. Keep labels on one plain-text line. Replace a semicolon in a label with a comma or a hyphen: a state description ends at the first semicolon and Mermaid reparses the remainder as further syntax, truncating the label and possibly adding a stray node while the diagram still parses. Prefer prose below the diagram to crowded notes. Avoid `classDef` styling inside composite states.

## Validate and deliver

Use the repository renderer or Mermaid CLI when available. Otherwise preview the diagram when practical and inspect it against the [official state-diagram grammar](https://mermaid.js.org/syntax/stateDiagram.html).

Report one validation status and name the method that produced it: `rendered` after a renderer produced output, `parser-checked` after a parser such as `mermaid.parse` accepted the text without drawing it, `previewed` after visual inspection in a viewer, `inspection-only` when no mechanical check was available. A parser check does not prove the chart means what you intended, because the grammar accepts unsupported transitions. Never report `rendered` for a diagram you only parsed or only read.

For each machine, return:

1. its name and source path, or a proposed-artifact label;
2. one fenced `mermaid` block;
3. material invokes, abstractions, and omitted non-state-changing events;
4. the validation method and result.
