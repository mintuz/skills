# Observable Pattern for Shared State

## When to Use @Observable

- App-wide managers (authentication, settings, network)
- Feature-specific coordinators
- Shared data models that multiple views need

## Observable Setup Pattern

```swift
@Observable
class SettingsManager {
    var theme: Theme = .system
    var notificationsEnabled = true
    var fontSize: FontSize = .medium

    func updateTheme(_ newTheme: Theme) {
        theme = newTheme
        // Persist to UserDefaults or elsewhere
    }
}
```

## Observable Services Pattern

Keep business logic in `@Observable` services for testability. A service holds data only when more than one screen reads it; a single screen keeps its own items, loading flag, and error in `@State`. Mark a service whose state a view reads `@MainActor` so its stored state is written on the main actor:

```swift
@Observable
@MainActor
class ItemService {
    private let api: APIClient
    var items: [Item] = []
    var isLoading = false
    var error: Error?

    init(api: APIClient = .shared) {
        self.api = api
    }

    func fetchItems() async throws {
        isLoading = true
        defer { isLoading = false }

        do {
            items = try await api.fetchItems()
            error = nil
        } catch {
            self.error = error
            throw error
        }
    }
}
```

Views stay thin and coordinate:

```swift
struct ItemListView: View {
    @Environment(ItemService.self) private var itemService

    var body: some View {
        List(itemService.items) { item in
            Text(item.name)
        }
        .task {
            try? await itemService.fetchItems()
        }
    }
}
```

For injection patterns and nested observables, see `references/state-management.md` and `references/anti-patterns.md`.
